
"use strict";
const CHANNEL_ID="UC09MdnfYuhyyC10fEQZFiqw";
const CHANNEL_URL="https://www.youtube.com/@djmixmamun";
const FEED_URL="https://www.youtube.com/feeds/videos.xml?channel_id="+encodeURIComponent(CHANNEL_ID);
const API_URL="https://api.rss2json.com/v1/api.json?rss_url="+encodeURIComponent(FEED_URL);
let videos=[];
function getVideoId(item){
 const values=[item.guid,item.link,item.id,item.url];
 for(const value of values){if(!value)continue;const m=String(value).match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|yt:video:)([A-Za-z0-9_-]{11})/);if(m)return m[1];if(/^[A-Za-z0-9_-]{11}$/.test(String(value)))return String(value);}
 return "";
}
function dateText(v){const d=new Date(v);return Number.isNaN(d.getTime())?"":d.toLocaleDateString("bn-BD",{year:"numeric",month:"short",day:"numeric"});}
async function loadFeed(){
 const status=document.getElementById("status");
 if(!status)return;
 status.textContent="YouTube-এর সর্বশেষ ভিডিও লোড হচ্ছে...";
 try{
  const res=await fetch(API_URL,{cache:"no-store"});
  if(!res.ok)throw new Error("Feed unavailable");
  const data=await res.json();
  if(data.status!=="ok"||!Array.isArray(data.items))throw new Error("Invalid feed");
  const seen=new Set();
  videos=data.items.map(item=>({id:getVideoId(item),title:String(item.title||"DJ MIX MAMUN Video"),date:item.pubDate||"",thumbnail:item.thumbnail||""}))
   .filter(v=>v.id&&!seen.has(v.id)&&seen.add(v.id)).slice(0,10);
  if(!videos.length)throw new Error("No public videos");
  status.textContent="সর্বশেষ "+videos.length+"টি ভিডিও পাওয়া গেছে।";
  renderFeed();
 }catch(e){
  status.textContent="ভিডিও লোড করা যায়নি। কিছুক্ষণ পর আবার চেষ্টা করুন অথবা YouTube চ্যানেল দেখুন।";
  const target=document.getElementById("videoGrid")||document.getElementById("playerGrid");
  if(target)target.innerHTML='<a class="btn youtube" href="'+CHANNEL_URL+'/videos" target="_blank" rel="noopener">YouTube-এ ভিডিও দেখুন</a>';
 }
}
function renderFeed(){
 const grid=document.getElementById("videoGrid");
 const players=document.getElementById("playerGrid");
 const search=document.getElementById("videoSearch");
 const q=search?search.value.trim().toLocaleLowerCase():"";
 const filtered=videos.filter(v=>v.title.toLocaleLowerCase().includes(q));
 if(grid){
  grid.replaceChildren();
  filtered.forEach(v=>{
   const card=document.createElement("article");card.className="video-card";
   const img=document.createElement("img");img.className="thumb";img.loading="lazy";img.src=v.thumbnail||`https://i.ytimg.com/vi/${v.id}/hqdefault.jpg`;img.alt=v.title;
   const info=document.createElement("div");info.className="card-info";
   const h=document.createElement("h3");h.textContent=v.title;
   const small=document.createElement("small");small.textContent=dateText(v.date);
   info.append(h,small);card.append(img,info);
   card.addEventListener("click",()=>{location.href="videos.html#"+v.id;});
   grid.append(card);
  });
  if(!filtered.length)grid.innerHTML='<p class="notice">এই নামে কোনো ভিডিও পাওয়া যায়নি।</p>';
 }
 if(players){
  players.replaceChildren();
  filtered.forEach(v=>{
   const item=document.createElement("article");item.className="player-item";
   const iframe=document.createElement("iframe");iframe.loading="lazy";iframe.src="https://www.youtube-nocookie.com/embed/"+encodeURIComponent(v.id);iframe.title=v.title;iframe.allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share";iframe.allowFullscreen=true;iframe.referrerPolicy="strict-origin-when-cross-origin";
   const h=document.createElement("h3");h.textContent=v.title;
   const small=document.createElement("small");small.textContent=dateText(v.date);
   item.append(iframe,h,small);players.append(item);
  });
  if(!filtered.length)players.innerHTML='<p class="notice">কোনো ভিডিও পাওয়া যায়নি।</p>';
 }
}
document.addEventListener("DOMContentLoaded",()=>{
 const year=document.getElementById("year");if(year)year.textContent=new Date().getFullYear();
 const search=document.getElementById("videoSearch");if(search)search.addEventListener("input",renderFeed);
 const refresh=document.getElementById("refreshBtn");if(refresh)refresh.addEventListener("click",()=>loadFeed());
 if(document.getElementById("videoGrid")||document.getElementById("playerGrid"))loadFeed();
});
